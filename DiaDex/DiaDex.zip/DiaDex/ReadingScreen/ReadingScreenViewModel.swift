import UIKit


class ReadingScreenViewModel {


}
