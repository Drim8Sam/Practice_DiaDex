//
//  ReadingScreenView.swift
//  DiaDex
//
//  Created by err on 03.04.2024.
//

import UIKit

class ReadingScreenView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        setUp()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setUp() {


    }

}
