import UIKit


class SignUpModelView {


}
