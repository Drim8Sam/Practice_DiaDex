//
//  CalendarViewModel.swift
//  DiaDex
//
//  Created by err on 01.06.2024.
//

import Foundation

class CalendarViewModel {
    
}
