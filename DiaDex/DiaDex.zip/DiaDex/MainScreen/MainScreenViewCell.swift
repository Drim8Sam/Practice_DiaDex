import UIKit

class MainScreenViewCell: UITableView {

    
}
