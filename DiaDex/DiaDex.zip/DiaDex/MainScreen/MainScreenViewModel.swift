import UIKit

class MainScreenViewModel {


}
