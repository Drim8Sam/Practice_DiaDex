//
//  SecondStepView.swift
//  DiaDex
//
//  Created by err on 08.07.2024.
//

import UIKit
import SnapKit

class SecondStepView: UIView {
    var viewController: SecondStepViewController!

}
