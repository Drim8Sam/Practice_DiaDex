import Foundation

class FirstStepViewModel {
    let values: [Double] = Array(stride(from: 1.0, to: 40.0, by: 0.1))
    let initialValue: Double = 5.6 // Set your initial value here
}
