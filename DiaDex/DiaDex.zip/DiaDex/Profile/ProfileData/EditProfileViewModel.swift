//
//  ProfileDataViewModel.swift
//  DiaDex
//
//  Created by err on 11.09.2024.
//

class EditProfileViewModel {
    
}
