//
//  ProfileViewModel.swift
//  DiaDex


import UIKit


class ProfileViewModel {

    
}
